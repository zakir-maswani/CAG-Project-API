from fastapi import APIRouter, UploadFile, File, HTTPException, Query
import uuid as uuid_pkg
import os
import logging # Import logging module for better error handling

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Import the shared data store (ensure this is correctly defined in src/utils/data_stores.py)
# If data_store is meant to be a global in this file, remove the import and define it here.
# Assuming it's meant to be imported:
try:
    from src.utils.data_stores import data_store
except ImportError:
    logging.warning("Could not import data_store from src.utils.data_stores. Using an in-memory dictionary.")
    data_store = {} # Fallback to an in-memory dictionary if import fails

# PDF processing utility
try:
    from src.utils.pdf_processor import extract_text_from_pdf
except ImportError:
    logging.error("Could not import extract_text_from_pdf from src.utils.pdf_processor. PDF processing will fail.")
    # Define a placeholder function to prevent immediate crashes
    def extract_text_from_pdf(file_path: str) -> str:
        logging.error(f"Placeholder: extract_text_from_pdf not implemented. File: {file_path}")
        raise NotImplementedError("PDF processor not available.")


# LLM client utility
try:
    from src.utils.llm_client import get_llm_response
except ImportError:
    logging.error("Could not import get_llm_response from src.utils.llm_client. LLM queries will fail.")
    # Define a placeholder function
    def get_llm_response(context: str, query: str) -> str:
        logging.error(f"Placeholder: get_llm_response not implemented. Context len: {len(context)}, Query: {query}")
        raise NotImplementedError("LLM client not available.")


router = APIRouter()

# Define temporary directory for uploads
# It's better to use a more robust temporary directory approach or
# ensure this path is writable and managed in a production environment.
# For Docker/Kubernetes, this might be a mounted volume.
UPLOAD_DIR = "/tmp/cag_uploads" # Changed to /tmp which is standard for temporary files
os.makedirs(UPLOAD_DIR, exist_ok=True)
logging.info(f"Upload directory created at: {UPLOAD_DIR}")


@router.post("/upload/{uuid}", status_code=201)
def upload_pdf(uuid: uuid_pkg.UUID, file: UploadFile = File(...)):
    """
    Uploads a PDF file associated with a specific UUID.
    Extracts text from the PDF and stores it in the data store.
    If the UUID already exists, it raises an error (use PUT to update).
    """
    if file.content_type != "application/pdf":
        raise HTTPException(
            status_code=400, detail="Invalid file type. Only PDF files are acceptable."
        )

    uuid_str = str(uuid)
    if uuid_str in data_store:
        raise HTTPException(
            status_code=400,
            detail=f"UUID {uuid_str} already exists. Use PUT /upload/{uuid_str} to append data."
        )

    # Use a more unique file name to avoid clashes, especially if multiple uploads
    # happen quickly for the same UUID (though POST prevents this, PUT might not)
    file_path = os.path.join(UPLOAD_DIR, f"{uuid_str}_{file.filename.replace(' ', '_')}")
    
    try:
        # Save the uploaded file temporarily
        # FIX: file.file.read needs to be called as a method: file.file.read()
        with open(file_path, "wb") as buffer:
            # Read in chunks for large files
            while contents := file.file.read(1024 * 1024): # Read 1MB at a time
                buffer.write(contents)
        logging.info(f"File saved temporarily at: {file_path}")

        # Extract text using the utility function
        extracted_text = extract_text_from_pdf(file_path)

        if extracted_text is None or not extracted_text.strip(): # Check for empty text too
            raise HTTPException(
                status_code=500, detail="Failed to extract text from PDF or extracted text was empty."
            )

        # Store the extracted text
        data_store[uuid_str] = extracted_text
        logging.info(f"Text extracted and stored for UUID: {uuid_str}")
        return {
            "message": "File uploaded and text extracted successfully",
            "uuid": uuid_str
        }

    except NotImplementedError as e:
        logging.error(f"Functionality not implemented: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        # Log the actual exception for debugging
        logging.error(f"An error occurred during file processing for UUID {uuid_str}: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred during file processing: {str(e)}"
        )

    finally:
        # Clean up the temporary file
        if os.path.exists(file_path):
            os.remove(file_path)
            logging.info(f"Temporary file cleaned up: {file_path}")


@router.put("/update/{uuid}")
def upload_pdf_data(uuid: uuid_pkg.UUID, file: UploadFile = File(...)):
    """
    Appends text extracted from a new PDF file to the existing data for a given UUID.
    If the UUID does not exist, it raises an error.
    """
    if file.content_type != "application/pdf":
        raise HTTPException(
            status_code=400, detail="Invalid file type. Only PDF files are acceptable."
        )

    uuid_str = str(uuid)
    if uuid_str not in data_store:
        raise HTTPException(
            status_code=404,
            detail=f"UUID {uuid_str} not found. Use POST /upload/{uuid_str} to create it first." # Corrected path
        )

    # FIX: file.filename was incorrectly used in f-string
    file_path = os.path.join(UPLOAD_DIR, f"{uuid_str}_update_{file.filename.replace(' ', '_')}")
    try:
        # Save the uploaded file temporarily
        # FIX: file.file.read needs to be called as a method: file.file.read()
        with open(file_path, "wb") as buffer:
            while contents := file.file.read(1024 * 1024): # Read 1MB at a time
                buffer.write(contents)
        logging.info(f"Update file saved temporarily at: {file_path}")

        # Extract text from the new PDF
        new_text = extract_text_from_pdf(file_path)

        if new_text is None or not new_text.strip(): # Check for empty text too
            raise HTTPException(
                status_code=500, detail="Failed to extract text from PDF or extracted text was empty."
            )

        # Append the new text (Add a separator for clarity)
        data_store[uuid_str] += "\n\n" + new_text
        logging.info(f"New text appended for UUID: {uuid_str}")
        return {"message": "Data appended successfully", "uuid": uuid_str}

    except NotImplementedError as e:
        logging.error(f"Functionality not implemented: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        # Log the actual exception for debugging
        logging.error(f"An error occurred during file update processing for UUID {uuid_str}: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred during file processing: {str(e)}"
        )

    finally:
        # Clean up the temporary file
        if os.path.exists(file_path):
            os.remove(file_path)
            logging.info(f"Temporary update file cleaned up: {file_path}")


# FIX: Typo in the path, should be /query/{uuid} and not /guery/{query}
@router.get("/query/{uuid}")
def query_data(uuid: uuid_pkg.UUID, query: str = Query(..., min_length=1)):
    """
    Retrieves the stored text for a given UUID and sends it along with a query
    to an LLM service.
    Returns the LLM's response.
    """

    uuid_str = str(uuid)
    if uuid_str not in data_store:
        raise HTTPException(
            status_code=404, detail=f"UUID {uuid_str} not found."
        )

    stored_data = data_store[uuid_str]
    logging.info(f"Querying LLM for UUID: {uuid_str} with query: '{query[:50]}...'") # Log partial query

    try:
        llm_response = get_llm_response(content=stored_data, query=query)
    except NotImplementedError as e:
        logging.error(f"LLM functionality not implemented: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    except Exception as e:
        logging.error(f"Error calling LLM for UUID {uuid_str}: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"An error occurred while getting LLM response: {str(e)}"
        )

    return {"uuid": uuid_str, "query": query, "llm_response": llm_response}


@router.delete("/data/{uuid}", status_code=200)
def delete_data(uuid: uuid_pkg.UUID):
    """
    Deletes the data associated with a specific UUID from the data store.
    """
    uuid_str = str(uuid)
    if uuid_str not in data_store:
        raise HTTPException(
            status_code=404, detail=f"UUID {uuid_str} not found."
        )

    del data_store[uuid_str]
    logging.info(f"Data for UUID {uuid_str} deleted successfully.")
    return {"message": f"Data for UUID {uuid_str} deleted successfully."}


@router.get("/list_uuids")
def list_all_uuids():
    """
    Returns a list of all UUIDs currently stored.
    """
    uuids = list(data_store.keys())
    logging.info(f"Returning list of {len(uuids)} UUIDs.")
    return {"uuids": uuids}