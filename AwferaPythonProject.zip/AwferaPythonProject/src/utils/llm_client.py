from groq import Groq
from dotenv import load_dotenv, find_dotenv
import os

# Load environment variables from .env file
load_dotenv(find_dotenv())

def get_llm_response(content: str, query: str) -> str:
    """
    Sends a query and context to Groq and returns the assistant's response.

    Args:
        content (str): Background information (will be integrated into the system message).
        query (str): The user's question.

    Returns:
        str: The assistant's generated text response.
    """

    api_key = os.environ.get('GROQ_API_KEY')
    if not api_key:
        raise ValueError(
            "GROQ_API_KEY environment variable is not set."
            "Please set it to your Groq API key."
        )

    # Initialize the Groq client
    client = Groq(api_key=api_key)

    # You can choose a model available on Groq.
    # Common ones include "llama3-8b-8192", "llama3-70b-8192", "mixtral-8x7b-32768".
    # Check Groq's documentation for the latest available models.
    model = "llama3-8b-8192" 

    messages = [
        {
            "role": "system",
            "content": f"You are a helpful assistant. Here's some context: {content}"
        },
        {
            "role": "user",
            "content": query
        },
    ]

    # Stream and accumulate the response
    response_text = ""
    # Groq's API for streaming is directly on the chat.completions.create method
    stream = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=0.7, # You can adjust this value
        max_tokens=2048, # You can adjust this value
        stream=True,
    )

    for chunk in stream:
        if chunk.choices[0].delta.content:
            response_text += chunk.choices[0].delta.content
    
    return response_text

# Example usage (you'll need to define your content and query)
if __name__ == "__main__":
    context_info = "The capital of France is Paris."
    user_question = "What is the capital of France?"
    
    try:
        response = get_llm_response(content=context_info, query=user_question)
        print("Groq Assistant's Response:")
        print(response)
    except ValueError as e:
        print(f"Error: {e}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")