# Centralized in-memory data storage
# In a real application, this would be replaced by a databse connection

data_store = {}