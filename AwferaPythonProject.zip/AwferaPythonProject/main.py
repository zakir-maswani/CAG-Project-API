from fastapi import FastAPI
from src.routers import data_handler 
from fastapi.responses import HTMLResponse
import uvicorn

app = FastAPI(
    title= "CAG Project API Chatwith Your PDF",
    description= "API for uploading PDFs, querying content via LLM, and managing data.",
    version= "1.0.0"
)

app.include_router(
    data_handler.router,
    prefix= "/api/v1",
    tags= ["Data Handling And Chat With PDF"]
)

@app.get("/", response_class= HTMLResponse, tags= ["Root"])
def read_root():
    """ 
    Provides a simple HTML welcome page with a link to the Swagger Docs.
    
    """

    html_content = """
    <!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>CAG Project API</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      margin: 0;
      background: #f1f4f9;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      max-width: 600px;
      background: #ffffff;
      padding: 2rem;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.05);
      text-align: center;
    }

    h1 {
      color: #222;
      margin-bottom: 1rem;
    }

    p {
      font-size: 1rem;
      color: #555;
      margin: 0.8rem 0;
    }

    a {
      display: inline-block;
      margin-top: 0.5rem;
      padding: 0.6rem 1.2rem;
      background-color: #007acc;
      color: white;
      text-decoration: none;
      border-radius: 6px;
      transition: background 0.3s;
    }

    a:hover {
      background-color: #005fa3;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Welcome to the CAG Project API</h1>
    <p>👉 View the automatically generated API documentation here:</p>
    <p>
      <a href="/docs" target="_blank">Swagger UI (GroqAI Docs)</a>
    </p>
  </div>
</body>
</html>
    
    """
    return HTMLResponse(content= html_content, status_code=200)

if __name__ == "__main__":
    uvicorn.run(app, host= "127.0.0.1", port= 8000)